package model;

public enum Boissons {
	
	BIERE,
	VIN,
	RHUM,
	WHISKY;
}


