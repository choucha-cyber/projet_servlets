package model;

public enum Lait {
	
	AVEC,
	SANS,
	SOJA;

}
