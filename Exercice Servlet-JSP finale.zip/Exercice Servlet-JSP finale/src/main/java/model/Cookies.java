package model;

public enum Cookies {
	
	DOUBLECHOCO,
	PEPITECHOCO,
	SUCRE,
	VANILLE;

}
